function bigImg(x) {
    x.style.height = "35px";
    x.style.width = "35px";
  }
  
  function normalImg(x) {
    x.style.height = "32px";
    x.style.width = "32px";
  }